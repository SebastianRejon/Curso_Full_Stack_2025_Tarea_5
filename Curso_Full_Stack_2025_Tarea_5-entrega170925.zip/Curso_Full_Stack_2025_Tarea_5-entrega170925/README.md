# Tarea_5
## Curso_Full_Stack_2025

Crear un formulario con Bootstrap que tenga:
- campo Nombre
- campo Email
- campo Mensaje (textarea)
- boton Envío

Asegúrate de que sea responsive y se vea bien en distintas pantallas.
En tu CSS propio, personaliza:

- Color del Botón
- Color o estilos de las líneas de los inputs (border)
